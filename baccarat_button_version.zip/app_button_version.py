
import streamlit as st
from utils import predict_next, count_results, make_trend_chart
import matplotlib.pyplot as plt

st.set_page_config(page_title="百家樂預測器（按鈕版）", layout="centered")

st.title("🔮 百家樂預測器（按鈕版）")

if "history" not in st.session_state:
    st.session_state.history = []

col1, col2, col3, col4 = st.columns(4)
with col1:
    if st.button("🟥 莊"):
        st.session_state.history.append("B")
with col2:
    if st.button("🟦 閒"):
        st.session_state.history.append("P")
with col3:
    if st.button("⬅️ 刪除"):
        if st.session_state.history:
            st.session_state.history.pop()
with col4:
    if st.button("🧹 清空"):
        st.session_state.history = []

if st.session_state.history:
    st.markdown("### 📘 歷史輸入：")
    st.write(", ".join(st.session_state.history))
    count_B, count_P, ratio_B, ratio_P = count_results(st.session_state.history)
    st.markdown("🧮 莊：{} 次（{:.1f}%）｜閒：{} 次（{:.1f}%）".format(count_B, ratio_B, count_P, ratio_P))
    prediction = predict_next(st.session_state.history)
    st.subheader(f"🔮 {prediction}")
    fig = make_trend_chart(st.session_state.history)
    st.pyplot(fig)
    if len(st.session_state.history) >= 2 and st.session_state.history[-1] == st.session_state.history[-2]:
        st.info("提示：連出兩次相同，建議反跳下注")
    elif len(set(st.session_state.history[-3:])) == 1:
        st.info("提示：連出三次相同，可考慮追打")
    else:
        st.info("提示：建議觀望，避免追高")
else:
    st.info("請點選上方按鈕輸入歷史結果")

｜閒：{} 次（{:.1f}%）".format(count_B, ratio_B, count_P, ratio_P))
    prediction = predict_next(st.session_state.history)
    st.subheader(f"🔮 {prediction}")
    fig = make_trend_chart(st.session_state.history)
    st.pyplot(fig)
    if len(st.session_state.history) >= 2 and st.session_state.history[-1] == st.session_state.history[-2]:
        st.info("提示：連出兩次相同，建議反跳下注")
    elif len(set(st.session_state.history[-3:])) == 1:
        st.info("提示：連出三次相同，可考慮追打")
    else:
        st.info("提示：建議觀望，避免追高")
else:
    st.info("請點選上方按鈕輸入歷史結果")
